# Frontend (placeholder)

This folder is a placeholder for a React or React Native frontend.

Suggested steps:
- Create a React app: `npx create-react-app web`
- Implement a simple chat UI that calls `http://localhost:8000/api/v1/chat`
- Use MediaRecorder for voice capture and POST audio to a `/voice/recognize` endpoint (to be implemented).
