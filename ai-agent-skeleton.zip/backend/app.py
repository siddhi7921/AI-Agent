from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="AI-Agent Backend")

class ChatRequest(BaseModel):
    session_id: str
    input: str

@app.get("/")
async def root():
    return {"status": "ok", "service": "AI-Agent Backend"}

@app.post("/api/v1/chat")
async def chat(req: ChatRequest):
    # TODO: integrate LLM and RAG
    return {"reply": f"Echo: {req.input}"}

@app.post("/api/v1/upload-doc")
async def upload_doc(file: UploadFile = File(...)):
    content = await file.read()
    # TODO: index content into vector DB
    return {"status": "received", "filename": file.filename}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
